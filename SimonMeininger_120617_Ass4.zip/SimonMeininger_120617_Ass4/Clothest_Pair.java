package de.assignment4_1;

public class Clothest_Pair {
	
	Clothest_Pair(){
		
	};
	
    public double getDistance(Point p1, Point p2){
        return Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2)); // (Basis,Exponent)
    };
    
    public void bruteForce(Point[] p) {	// loops-compare all the points to get the pair with the smallest dist.
    	double min = Integer.MAX_VALUE;
    	int p1 = Integer.MAX_VALUE;
    	int p2 = Integer.MAX_VALUE;
    	for (int i = 0; i < p.length; i++) {
    		for (int j = i+1; j < p.length; ++j) {  
    			if (getDistance(p[i], p[j]) < min) {  
    	           min = getDistance(p[i], p[j]);
    	           p1 = i;
    	           p2 = j;
    			}
    		}
    	}
    	System.out.println("Position Point1 in array : " + p1 + " . coordinates (x / y):  " + p[p1].x + " / " + p[p1].y);
    	System.out.println("Position Point2 in array : " + p2 + " . coordinates (x / y):  " + p[p2].x + " / " + p[p2].y);
    	System.out.println("The Distance is :  " + min);
    }
    
    public Point[] selectionSort_x (Point[] sort) {	// required sorting-method for the div&con -algor. (for x-coordin)
		
			for(int i = 0; i < sort.length - 1; i++ ) {			
				for(int j = i + 1; j < sort.length; j++) {				
					if (sort[j].x < sort[i].x) {
						int help = sort [i].x;
						sort[i].x = sort[j].x;
						sort[j].x = help;
					}
				}
			}
		return sort;
	}
    
    public Point[] selectionSort_y (Point[] sort) {	// 				- " - (for y-coordin)
		
			for(int i = 0; i < sort.length - 1; i++ ) {			
				for(int j = i + 1; j < sort.length; j++) {				
					if (sort[j].y < sort[i].y) {
						int help = sort [i].y;
						sort[i].y = sort[j].y;
						sort[j].y = help;
					}
				}
			}
		return sort;
	}
    
    public void print_ar(Point[] a1){			// for check the elements of the arr_DC by printout
		for (int i = 0; i < a1.length; i++){
			System.out.println("  " + a1[i].x + " , " + a1[i].y + "   ");
		}
	}

    
	public Point dc_rek(Point[] arr_DC){  // rekursiv method  div&con clothest pair
		
		Point p = new Point(); // 
		Point right_min = new Point();
		Point left_min = new Point();
		
		left_min.d = Float.MAX_VALUE;
		right_min.d = Float.MAX_VALUE;
		p.d = Float.MAX_VALUE;
		
		Point[] left = new Point[arr_DC.length/2]; 
		Point[] right = new Point[arr_DC.length/2];
		
		float min = Float.MAX_VALUE;
		selectionSort_x(arr_DC);
	
				//transfer the two halfs of the input-array in sub-arrays (left and right)   
		for (int i = 0; i <= arr_DC.length/2; i++){ 
			left[i] = arr_DC[i];
		}		
		for (int i = (arr_DC.length/2)+1; i < arr_DC.length; i++){
			right[i] = arr_DC[i];
		}
				
		left_min = dc_rek(left); 
		right_min = dc_rek(right); 
		
		return  p;
	}
}
    
    
    

