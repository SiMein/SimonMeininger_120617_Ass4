package de.assignment4_1;

public class Clothest_Pair_Test {

	public static void main(String[] args) {

		Point p1 = new Point(1,1);			// create some coordinates
		Point p2 = new Point(-1,-1);
		Point p3 = new Point(11,5);
		Point p4 = new Point(100,50);
		Point p5 = new Point(99,1);
		Point p6 = new Point(60,40);
		Point p7 = new Point(10,10);
		
		Point p[] = {p1,p2,p3,p4,p5,p6,p7}; // put the coordinates in a array
		    
		Clothest_Pair cp1 = new Clothest_Pair();  // class with methods to work with
		    
		System.out.println("Single-Points-Check : " + cp1.getDistance(p1, p6)); // for checking distance between two single points
		
		System.out.println("bruteForce-Check for the array :  "); 
		cp1.bruteForce(p);	// for checking & printout the 2 points in the array with the (first found) smallest
							// distance in a "classic" way O(n^2)
		
		System.out.println("After sorting x :");
		cp1.selectionSort_x(p);	// check selction-sorting-methods - needed in the div&cong-algor. 
		cp1.print_ar(p);
		System.out.println("After sorting y :");
		cp1.selectionSort_y(p);
		cp1.print_ar(p);
		// of course by testing  x and y in the array is sorted - so look at the printout what are the new coordinates 
		
		// for testing div&con-algo-- again here the same array like at the beginning
		
		Point p10 = new Point(1,1);			// create some coordinates
		Point p20 = new Point(-1,-1);
		Point p30 = new Point(11,5);
		Point p40 = new Point(100,50);
		Point p50 = new Point(99,1);
		Point p60 = new Point(60,40);
		Point p70 = new Point(10,10);
		
		Point p0[] = {p1,p2,p3,p4,p5,p6,p7}; // put the coordinates in a array
		
		Clothest_Pair cp0 = new Clothest_Pair();
		
//		cp0.dc_rek(p0);  
	
	}

}
