package de.assignment4_1;

public class Point {	// for keep it simple only the coordinates here in whole numbers  , 
	public int x;
	public int y;
	public float d;
	
	Point(){		// default -constr
		
	};
	
	Point(int x, int y) {	// custum-constr.
		this.x = x;
		this.y = y;
	}; 
}
